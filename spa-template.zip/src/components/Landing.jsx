import React from 'react';

export default function Landing() {
  return <h1>Landing Page</h1>;
}
