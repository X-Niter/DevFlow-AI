import React from 'react';

export default function Onboarding() {
  return <h1>Onboarding Page</h1>;
}
