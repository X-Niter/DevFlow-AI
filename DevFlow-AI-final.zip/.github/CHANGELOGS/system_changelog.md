### 🔧 System Updates

- Added system_changelog.html page
- Split plugin vs workflow changelogs
